#Spring Bean Lifecycle example
